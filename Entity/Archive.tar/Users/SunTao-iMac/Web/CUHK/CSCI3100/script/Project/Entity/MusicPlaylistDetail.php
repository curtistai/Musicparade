<?php
require_once('Database_connection.php');

class MusicPlayListDetail
{
	
	private $musSerial;
	private $musListSerial;
	
	

	public function __construct($serial, $mSerial)
	{
		self::$musSerial = $serial;
		self::$musListSerial = $mSerial;
		
		
	}
	
	
	public function getMusSerial()
	{
	  return $musSerial;
	}
	
	public function getMusListSerial()
	{
	  return $musListSerial;
	}
	
	
	

	public function setMusSerial($serial){ $musSerial = $serial; }

    public function setMusListSerial($mSerial){ $musListSerial = $mSerial; } 
	
 

    
	//////////////////////////////////////////////////////////////
		public function insert($musSerial, $musicPlayListSerial)
	{
		$insertMusicPlaylistDetail = mysql_query('INSERT INTO MusicPlayListDetail VALUES ('.$musSerial.',\''.$musListSerial.'\')');
		
	}
}
?>