<?php
require_once('Database_connection.php');

class ErrorReport
{
	private $errorDescription;
	private $errorReportDate;
	

	public function __construct($desccription, $reportDate)
	{
		self::$errorDescription = $desccription;
		self::$errorReportDate = $reportDate;
	}
	
	
	
	public function getErrorDescription()
	{
	  return $errorDescription;
	}
	
	public function getErrorReportDate()
	{
	  return $errorReportDate;
	}
	

	public function setErrorDescription($desccription){ $errorDescription = $desccription; }

    public function setErrorReportDate($reportDate){ $errorReportDate = $reportDate; } 
	
    
	//////////////////////////////////////////////////////////////
	public function insert($error)
	{
		$insertError = mysql_query('INSERT INTO ErrorReport VALUES (\''.$errorDescription.'\' ,\''.date("Y-m-d").'\')');
		
	}
}
?>