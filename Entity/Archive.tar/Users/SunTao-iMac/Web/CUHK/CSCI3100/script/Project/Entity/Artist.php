<?php
require_once('Database_connection.php');
require_once('Music.php');

class Artist
{
	private $artSerial;
	private $artName;
	

	public function __construct($serial, $name)
	{
		$artSerial = $serial;
		$artName = $name;
	}
	
	
	
	public function getArtSerial()
	{
	  return $artSerial;
	}
	
	public function getArtName()
	{
	  return $artName;
	}
	

	public function setArtSerial($serial){ $musSerial = $serial; }

	public function setArtName($name){ $artName = $name; } 
	
    
	//////////////////////////////////////////////////////////////
	public function findAllMusic()
	{
		$rawMusList = mysql_query('SELECT * FROM Music');
		$musList = array();
		while (($record = mysql_fetch_array($rawMusList)))
		{
			#echo $record[0]." ".$record[1]." ".$record[2]." ".$record[3]." ".$record[4];
			$musList[$record[0]] = new Music($record[0], $record[1], $record[2], $record[3], $record[4]);
			#print_r($musList);
		}

		return $musList;
	}
}
?>