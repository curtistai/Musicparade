<?php
require_once('Database_connection.php');

class Member
{
	
	private $memSerial;
	private $memLName;
	private $memFName;
	private $memEmail;
	private $memRegdate;
	private $memFacebook;

	public function __construct($serial, $lName,$fName,$email,$rDate,$facebook)
	{
		self::$memSerial = $serial;
		self::$memLName = $lName;
		self::$memFName = $fName;
		self::$memEmail = $email;
		self::$memRegdate = $rDate;
		self::$memFacebook = $facebook;
	}
	
	
	public function getMemSerial()
	{
	  return $memSerial;
	}
	
	public function getMemLName()
	{
	  return $memLName;
	}
	
	public function getMemFName()
	{
	  return $memFName;
	}
	
	public function getMemEmail()
	{
	  return $memEmail;
	}
	
	public function getMemRegdate()
	{
	  return $memRegdate;
	}
	
	public function getMemFacebook()
	{
	  return $memFacebook;
	}
	

	public function setMemSerial($serial){ $memSerial = $serial; }

    public function setMemLName($lName){ $memLName = $lName; } 
	
    public function setMemFName($fName){ $memFName = $fName; }
    
	public function setMemEmail($email){ $memEmail = $email; }

    public function setMemRegdate($rDate){ $memRegdate = $rDate; } 
	
    public function setMemFacebook($facebook){ $memFacebook = $facebook; }
    
	//////////////////////////////////////////////////////////////
	public function findAllMusic()
	{
		$rawMusList = mysql_query('SELECT * FROM Music');
		$musList = array();
		while (($record = mysql_fetch_array($rawMusList)))
		{
			$musList[$record[0]] = new Music($record[0], $record[1], $record[2], $record[3], $record[4]);
		}

		return $musList;
	}
}
?>