<?php
require_once('Database_connection.php');

class MusicType
{
	
	private $musTypeSerial;
	private $musType;
	
	

	public function __construct($serial, $type)
	{
		self::$musTypeSerial = $serial;
		self::$musType = $type;
		
		
	}
	
	
	public function getMusTypeSerial()
	{
	  return $musTypeSerial;
	}
	
	public function getMusType()
	{
	  return $musType;
	}
	
	
	
	public function setMusTypeSerial($serial){ $musTypeSerial = $serial; }

    public function setMusType($type){ $musType = $type; } 
	
 

    
	//////////////////////////////////////////////////////////////
	public function findAllMusic()
	{
		$rawMusList = mysql_query('SELECT * FROM Music');
		$musList = array();
		while (($record = mysql_fetch_array($rawMusList)))
		{
			$musList[$record[0]] = new Music($record[0], $record[1], $record[2], $record[3], $record[4]);
		}

		return $musList;
	}
}
?>