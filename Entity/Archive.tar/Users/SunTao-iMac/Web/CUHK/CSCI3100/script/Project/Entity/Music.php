<?php
require_once('Database_connection.php');

class Music
{
	public $musSerial;
	public $musName;
	public $publishDate;
	public $musTypeSerial;
	public $musStoredPath;

	public function __construct($serial, $name, $date, $typeSerial, $storedPath)
	{
		$this->musSerial = $serial;
		$this->musName = $name;
		$this->publishDate = $date;
		$this->musTypeSerial = $typeSerial;
		$this->musStoredPath = $storedPath;
	}

	public function setMusSerial($serial){ $musSerial = $serial; }

	public function getMusSerial(){ return $this->musSerial; }
	public function getMusName(){ return $this->musName; }

	public function findMusicBySerial($musicSerial)
	{
		$rawMusList = mysql_query('SELECT * FROM Music WHERE musSerial = '.$musicSerial);
		$musList = array();
		while (($record = mysql_fetch_array($rawMusList)))
		{
			$musList[$record[0]] = new Music($record[0], $record[1], $record[2], $record[3], $record[4]);
		}

		return $musList;
	}
	
}
?>
