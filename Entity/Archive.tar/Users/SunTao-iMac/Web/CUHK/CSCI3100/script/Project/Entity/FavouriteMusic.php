<?php
require_once('Database_connection.php');

class FavouriteMusic
{
	private $musSerial;
	private $memSerial;
	private $fmusAddDate;

	public function __construct($serial, $mSerial,$addDate)
	{
		self::$musSerial = $serial;
		self::$memSerial = $mSerial;
		self::$fmusAddDate = $addDate;
	}
	
	
	public function getMusSerial()
	{
	  return $musSerial;
	}
	
	public function getMemSerial()
	{
	  return $memSerial;
	}
	
	public function getFmusAddDate()
	{
	  return $fmusAddDate;
	}

	public function setMusSerial($serial){ $musSerial = $serial; }

    public function setMemSerial($mSerial){ $memSerial = $mSerial; } 
	
    public function setFmusAddDate($addDate){ $fmusAddDate = $addDate; }
    
	//////////////////////////////////////////////////////////////
	public function findAllMusic()
	{
		$rawMusList = mysql_query('SELECT * FROM Music');
		$musList = array();
		while (($record = mysql_fetch_array($rawMusList)))
		{
			$musList[$record[0]] = new Music($record[0], $record[1], $record[2], $record[3], $record[4]);
		}

		return $musList;
	}
}
?>