<?php
require_once('Database_connection.php');

class FollowArtlistList
{
	
	private $memSerial;
	private $artSerial;
	private $followDate;

	public function __construct($serial, $aSerial,$fDate)
	{
		self::$memSerial = $serial;
		self::$artSerial = $aSerial;
		self::$followDate = $fDate;
	}
	
	
	public function getMemSerial()
	{
	  return $memSerial;
	}
	
	public function getArtSerial()
	{
	  return $artSerial;
	}
	
	public function getFollowDate()
	{
	  return $followDate;
	}

	public function setMemSerial($serial){ $memSerial = $serial; }

    public function setArtSerial($aSerial){ $artSerial = $aSerial; } 
	
    public function setFollowDate($fDate){ $followDate = $fDate; }
    
	//////////////////////////////////////////////////////////////
	public function findAllMusic()
	{
		$rawMusList = mysql_query('SELECT * FROM Music');
		$musList = array();
		while (($record = mysql_fetch_array($rawMusList)))
		{
			$musList[$record[0]] = new Music($record[0], $record[1], $record[2], $record[3], $record[4]);
		}

		return $musList;
	}
}
?>