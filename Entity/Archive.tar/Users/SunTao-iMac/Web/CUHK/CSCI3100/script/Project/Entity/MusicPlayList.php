<?php
require_once('Database_connection.php');

class MusicPlayList
{
	
	private $musListSerial;
	private $memSerial;
	private $musListName;
	private $musListCreateDate;
	

	public function __construct($serial, $mSerial,$mName,$mDate)
	{
		self::$musListSerial = $serial;
		self::$memSerial = $mSerial;
		self::$musListName = $mName;
		self::$musListCreateDate = $mDate;
		
	}
	
	
	public function getMusListSerial()
	{
	  return $musListSerial;
	}
	
	public function getMemSerial()
	{
	  return $memSerial;
	}
	
	public function getMusListName()
	{
	  return $musListName;
	}
	
	public function getMusListCreateDate()
	{
	  return $musListCreateDate;
	}
	
	
	

	public function setMusListSerial($serial){ $musListSerial = $serial; }

    public function setMemSerial($mSerial){ $memSerial = $mSerial; } 
	
    public function setMusListName($mName){ $musListName = $mName; }
    
	public function setMusListCreateDate($mDate){ $musListCreateDate = $mDate; }

    
	//////////////////////////////////////////////////////////////
	public function insert($memSerial, $musListName, $date)
	{
		$insertMusicPlaylist = mysql_query('INSERT INTO MusicPlayList VALUES ('.$musicSerial.',\''.$musListName.'\','.$date.')');
		
	}
}
?>